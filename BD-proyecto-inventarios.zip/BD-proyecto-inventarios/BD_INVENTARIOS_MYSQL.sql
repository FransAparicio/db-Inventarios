CREATE DATABASE bd_inventario_compra_venta;
USE bd_inventario_compra_venta;

CREATE TABLE users(
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(200) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE roles(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT
);

CREATE TABLE permissions(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT
);

CREATE TABLE role_user(
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_id INT NOT NULL,
    user_id INT NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);


CREATE TABLE permission_role(
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_id INT NOT NULL,
    permission_id INT NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(id),
    FOREIGN KEY (permission_id) REFERENCES permissions(id)
);

CREATE TABLE clienteproveedors(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_completo VARCHAR(150) NOT NULL,
    correo VARCHAR(250),
    razon_social VARCHAR(200),
    numero_identificacion VARCHAR(30),
    telefono VARCHAR(25),
    estado BOOLEAN
);

CREATE TABLE sucursales(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    direccion VARCHAR(250) NOT NULL,
    telefono VARCHAR(20) NOt NULL,
    ciudad VARCHAR(100) NOT NULL,
    estado BOOLEAN
);

CREATE TABLE sucursal_user(
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    sucursal_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (sucursal_id) REFERENCES sucursales(id)
);

CREATE TABLE almacenes(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    codigo VARCHAR(100),
    descripcion TEXT,
    sucursal_id INT NOT NULL,
    FOREIGN KEY (sucursal_id) REFERENCES sucursales(id)
);

CREATE TABLE categorias(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT
);

CREATE TABLE productos(
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(100),
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    precio_venta_actual DECIMAL(12,2),
    imagen VARCHAR(255),
    estado BOOLEAN,
    categoria_id INT NOT NULL,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);


CREATE TABLE inventarios(
    id INT AUTO_INCREMENT PRIMARY KEY,
    cantidad_actual INT NOT NULL,
    fecha_actualizacion DATE NOT NULL,
    almacen_id INT NOT NULL,
    producto_id INT NOT NULL,
    FOREIGN KEY (almacen_id) REFERENCES almacenes(id),
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);

CREATE TABLE notas(
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATETIME NOT NULL,
    tipo_nota VARCHAR(20) NOT NULL,
    descuento_total DECIMAL(12,2),
    observaciones TEXT,
    clienteproveedor_id INT NOT NULL,
    user_id INT NOT NULL,
    FOREIGN KEY (clienteproveedor_id) REFERENCES clienteproveedors(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);


CREATE TABLE movimientos(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nota_id INT NOT NULL,
    producto_id INT NOT NULL,
    almacen_id INT NOT NULL,
    tipo_movimiento VARCHAR(20) NOT NULL,
    precio_unitario_compra DECIMAL(12,2) NOT NULL,
    precio_unitario_venta DECIMAL(12,2) NOT NULL,
    observaciones TEXT,
    FOREIGN KEY (nota_id) REFERENCES notas(id),
    FOREIGN KEY (producto_id) REFERENCES productos(id),
    FOREIGN KEY (almacen_id) REFERENCES almacenes(id)
);
